/* assets/app.js — V3.1
   Monthly multi-session claim prototype (client-side only)

   Key changes in V3.1:
   - Single reporting month control (type="month").
   - One session rendered by default.
   - Session-level Specialty removed.
   - Specimen rows include tissueType (Breast, Neck, Lung, Skin, Other).
   - Compact error banner with session chips and per-session inline summaries.
   - Monthly total points pill updated live.
   - Save/load drafts, JSON/CSV export (files named using ESR + reporting YYYY-MM).
*/

/* ===== Utilities ===== */
const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

function downloadFile(filename, content, mime = 'application/octet-stream') {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function buildCSV(headers, rows) {
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const headerLine = headers.map(esc).join(',');
  const lines = rows.map(r => headers.map(h => esc(r[h])).join(','));
  return [headerLine, ...lines].join('\n');
}

function generateUUID() {
  if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
  return `${hex.substr(0,8)}-${hex.substr(8,4)}-${hex.substr(12,4)}-${hex.substr(16,4)}-${hex.substr(20,12)}`;
}

/* LocalStorage keys */
const DRAFT_KEY = 'claimV3_1_draft_v1';
const USED_SESSION_IDS_KEY = 'claimV3_1_usedSessionIds_v1';

function getUsedSessionIds() {
  try { return new Set(JSON.parse(localStorage.getItem(USED_SESSION_IDS_KEY) || '[]')); } catch { return new Set(); }
}
function markSessionIdUsed(id) {
  const s = getUsedSessionIds();
  s.add(id);
  localStorage.setItem(USED_SESSION_IDS_KEY, JSON.stringify(Array.from(s)));
}

/* DOM refs */
const form = $('#claimForm');
const sessionsList = $('#sessionsList');
const addSessionBtn = $('#addSessionBtn');
const saveDraftBtn = $('#saveDraftBtn');
const loadDraftBtn = $('#loadDraftBtn');
const submitBtn = $('#submitBtn');
const resetBtn = $('#resetBtn');
const errorBanner = $('#errorBanner');
const sessionChips = $('#sessionChips');
const goToFirstErrorBtn = $('#goToFirstError');
const monthlyTotalValue = $('#monthlyTotalValue');
const prepareEmailBtn = $('#prepareEmailBtn');
const budgetEmailInput = $('#budgetEmail');

const KPI_TARGET = 36;

/* Runtime counters */
let sessionCounter = 0;

/* Initialise on DOM ready */
document.addEventListener('DOMContentLoaded', () => {
  addSession(); // one session by default

  // Bind top-level controls
  addSessionBtn.addEventListener('click', () => addSession());
  saveDraftBtn.addEventListener('click', saveDraft);
  loadDraftBtn.addEventListener('click', loadDraft);
  resetBtn.addEventListener('click', handleReset);
  form.addEventListener('submit', handleSubmit);
  goToFirstErrorBtn.addEventListener('click', focusFirstError);
  budgetEmailInput.addEventListener('input', handleBudgetEmailChange);
  prepareEmailBtn.addEventListener('click', prepareBudgetEmail);

  // Validate as users interact with top-level fields
  $$('#reportingMonth, #clinicianName, #grade, #esr, #directorate, #clinConfirmed, #clinInitials, #clinDate, #budgetName, #budgetInitials, #budgetDate').forEach(el => {
    el.addEventListener('input', () => validateForm());
  });

  validateForm();
});

/* ---------- Session & specimen DOM building ---------- */

/* Add a new session card. prefill (optional) allows loading drafts. */
function addSession(prefill = null) {
  const sessionId = (() => {
    const used = getUsedSessionIds();
    let id;
    do { id = generateUUID(); } while (used.has(id));
    markSessionIdUsed(id);
    return id;
  })();

  sessionCounter++;
  const idx = sessionCounter;
  const card = document.createElement('section');
  card.className = 'session-card';
  card.dataset.sessionId = sessionId;
  card.setAttribute('aria-label', `Session ${idx}`);
  card.innerHTML = `
    <div class="session-header">
      <div class="session-meta">
        <strong>Session <span class="session-number">${idx}</span></strong>
        <span class="session-date-display muted" style="margin-left:8px;">(date not set)</span>
      </div>
      <div>
        <button type="button" class="session-toggle btn-link" aria-expanded="true">Collapse</button>
        <button type="button" class="remove-session" title="Remove session">Remove session</button>
      </div>
    </div>

    <div class="session-body">
      <div class="grid grid-2">
        <label>Session ID
          <input type="text" class="session-id" name="sessionId" value="${sessionId}" readonly>
        </label>

        <label>Date
          <input type="date" class="session-date" required>
          <div class="input-error" aria-live="polite"></div>
        </label>

        <label>Start time
          <input type="time" class="session-start" required>
          <div class="input-error" aria-live="polite"></div>
        </label>

        <label>Finish time
          <input type="time" class="session-finish" required>
          <div class="input-error" aria-live="polite"></div>
        </label>

        <label>Location
          <select class="session-location" required>
            <option value="">Select...</option>
            <option>On-site</option>
            <option>Off-site</option>
            <option>Virtual</option>
          </select>
          <div class="input-error" aria-live="polite"></div>
        </label>

        <label>Reason
          <select class="session-reason" required>
            <option value="">Select...</option>
            <option>Waiting list initiative</option>
            <option>Backlog Reduction</option>
          </select>
          <div class="input-error" aria-live="polite"></div>
        </label>
      </div>

      <div class="session-metrics" style="margin-top:10px;">
        <div class="kpi-row">
          <div class="kpi-badge" aria-hidden="true">—</div>
          <div class="kpi-label">KPI status</div>
        </div>
        <div class="muted small" style="margin-top:6px;">
          <strong>Cases reported:</strong> <span class="casesReported">0</span> &nbsp;&nbsp;
          <strong>Session total points:</strong> <span class="totalPoints">0</span>
        </div>

        <div class="session-inline-errors" aria-live="polite"></div>

        <h4 style="margin-top:10px;">Specimen list</h4>
        <table class="specimens-table" aria-describedby="specimenHint">
          <thead>
            <tr>
              <th>Specimen number</th>
              <th>Urgency</th>
              <th>Tissue type</th>
              <th>Points</th>
              <th class="col-actions">Remove</th>
            </tr>
          </thead>
          <tbody class="specimens-body"></tbody>
        </table>
        <div class="actions" style="margin-top:8px;">
          <button type="button" class="add-specimen btn-secondary">+ Add specimen</button>
        </div>
      </div>
    </div>
  `;

  sessionsList.appendChild(card);

  // Wire up local controls
  const toggleBtn = card.querySelector('.session-toggle');
  const body = card.querySelector('.session-body');
  toggleBtn.addEventListener('click', () => {
    const expanded = toggleBtn.getAttribute('aria-expanded') === 'true';
    toggleBtn.setAttribute('aria-expanded', String(!expanded));
    toggleBtn.textContent = expanded ? 'Expand' : 'Collapse';
    body.style.display = expanded ? 'none' : '';
  });

  const removeBtn = card.querySelector('.remove-session');
  removeBtn.addEventListener('click', () => {
    if (!confirm('Remove this session? This cannot be undone.')) return;
    card.remove();
    updateSessionNumbers();
    validateForm();
  });

  // Add specimen row button
  card.querySelector('.add-specimen').addEventListener('click', () => addSpecimenRow(card));

  // Input listeners for session fields
  ['.session-date', '.session-start', '.session-finish', '.session-location', '.session-reason'].forEach(sel => {
    const el = card.querySelector(sel);
    if (el) el.addEventListener('input', () => { refreshSession(card); validateForm(); });
  });

  // Add one specimen by default
  addSpecimenRow(card);

  // Prefill if provided (draft load)
  if (prefill) populateSessionFromObject(card, prefill);

  refreshSession(card);
  updateSessionNumbers();
  validateForm();
}

/* Add a specimen row inside a given session card. prefill optional */
function addSpecimenRow(sessionCard, prefill = {}) {
  const tbody = sessionCard.querySelector('.specimens-body');
  const tr = document.createElement('tr');

  tr.innerHTML = `
    <td><input type="text" class="specimen-number" required></td>
    <td>
      <select class="specimen-urgency" required>
        <option value="">Select...</option>
        <option>Urgent</option>
        <option>Routine</option>
      </select>
    </td>
    <td>
      <select class="specimen-tissue" required>
        <option value="">Select...</option>
        <option>Breast</option>
        <option>Neck</option>
        <option>Lung</option>
        <option>Skin</option>
        <option>Other</option>
      </select>
    </td>
    <td><input type="number" class="specimen-points" min="0" step="1" required></td>
    <td class="col-actions"><button type="button" class="remove-specimen btn-secondary">Remove</button></td>
  `;

  tbody.appendChild(tr);

  // Prefill values if given
  if (prefill.specimenNumber) tr.querySelector('.specimen-number').value = prefill.specimenNumber;
  if (prefill.urgency) tr.querySelector('.specimen-urgency').value = prefill.urgency;
  if (prefill.tissueType) tr.querySelector('.specimen-tissue').value = prefill.tissueType;
  if (typeof prefill.points !== 'undefined') tr.querySelector('.specimen-points').value = prefill.points;

  // Bind events
  tr.querySelectorAll('input, select').forEach(el => el.addEventListener('input', () => { refreshSession(sessionCard); validateForm(); }));

  tr.querySelector('.remove-specimen').addEventListener('click', () => {
    if (!confirm('Remove this specimen row?')) return;
    tr.remove();
    refreshSession(sessionCard);
    validateForm();
  });

  // Focus the specimen number input for keyboard users
  tr.querySelector('.specimen-number').focus();

  refreshSession(sessionCard);
  validateForm();
}

/* Update session numbering after add/remove */
function updateSessionNumbers() {
  const cards = Array.from(sessionsList.querySelectorAll('.session-card'));
  cards.forEach((card, i) => {
    const numEl = card.querySelector('.session-number');
    if (numEl) numEl.textContent = String(i + 1);
    card.setAttribute('aria-label', `Session ${i + 1}`);
  });
}

/* ---------- Refresh / Metrics ---------- */

/* Refresh display for a single session: update case counts, totals, KPI badge, header date */
function refreshSession(sessionCard) {
  // Header date display
  const dateInput = sessionCard.querySelector('.session-date');
  const dateDisplay = sessionCard.querySelector('.session-date-display');
  dateDisplay.textContent = dateInput && dateInput.value ? dateInput.value : '(date not set)';

  // Compute cases & totals
  const rows = Array.from(sessionCard.querySelectorAll('.specimens-body tr'));
  let casesReported = 0;
  let totalPoints = 0;
  rows.forEach(r => {
    const specNum = r.querySelector('.specimen-number').value.trim();
    const ptsVal = r.querySelector('.specimen-points').value;
    if (specNum !== '') casesReported++;
    const pts = ptsVal === '' ? 0 : Number(ptsVal);
    if (Number.isFinite(pts)) totalPoints += pts;
  });

  sessionCard.querySelector('.casesReported').textContent = String(casesReported);
  sessionCard.querySelector('.totalPoints').textContent = String(totalPoints);

  // KPI badge
  const badge = sessionCard.querySelector('.kpi-badge');
  const label = sessionCard.querySelector('.kpi-label');
  if (totalPoints < KPI_TARGET) {
    badge.style.background = 'var(--kpi-red)';
    badge.textContent = String(totalPoints);
    label.textContent = 'Below target';
  } else if (totalPoints === KPI_TARGET) {
    badge.style.background = 'var(--kpi-green)';
    badge.textContent = String(totalPoints);
    label.textContent = 'On target';
  } else {
    badge.style.background = 'var(--kpi-orange)';
    badge.textContent = String(totalPoints);
    label.textContent = 'Over target';
  }

  // Update monthly total
  updateMonthlyTotal();
}

/* Sum across all sessions for monthly total */
function updateMonthlyTotal() {
  const cards = Array.from(sessionsList.querySelectorAll('.session-card'));
  let monthlyTotal = 0;
  cards.forEach(card => {
    const tp = Number(card.querySelector('.totalPoints').textContent) || 0;
    monthlyTotal += tp;
  });
  monthlyTotalValue.textContent = String(monthlyTotal);
}

/* ---------- Validation & compact error banner ---------- */

/* Collect errors and also per-session error summaries */
function collectErrors() {
  const errors = []; // global errors list {el, message}
  const sessionSummaries = []; // per-session { card, count, messages[], firstEl }

  // Reporting month required
  const reportingMonth = $('#reportingMonth').value;
  if (!reportingMonth) errors.push({ el: $('#reportingMonth'), message: 'Reporting month is required.' });

  // Clinician fields
  [['clinicianName','Name is required.'],
   ['grade','Grade is required.'],
   ['esr','Assignment / ESR is required.'],
   ['directorate','Directorate / Specialty is required.']
  ].forEach(([id, msg]) => {
    const el = $(`#${id}`);
    if (!el || !el.value || String(el.value).trim() === '') errors.push({ el, message: msg });
  });

  // Declarations
  if (!$('#clinConfirmed').checked) errors.push({ el: $('#clinConfirmed'), message: 'Clinician declaration must be confirmed.' });
  [['clinInitials','Clinician initials required.'],
   ['clinDate','Clinician declaration date required.'],
   ['budgetName','Budget holder name required.'],
   ['budgetInitials','Budget holder initials required.'],
   ['budgetDate','Budget holder approval date required.']
  ].forEach(([id, msg]) => {
    const el = $(`#${id}`);
    if (!el || !el.value || String(el.value).trim() === '') errors.push({ el, message: msg });
  });

  // Sessions: must have at least one session
  const cards = Array.from(sessionsList.querySelectorAll('.session-card'));
  if (cards.length === 0) {
    errors.push({ el: addSessionBtn, message: 'At least one session is required.' });
    return { errors, sessionSummaries }; // no per-session checks possible
  }

  // Validate each session and collect short messages
  cards.forEach((card, sIdx) => {
    const prefix = `Session ${sIdx + 1}`;
    const localMsgs = [];
    let localCount = 0;
    let firstEl = null;

    const dateEl = card.querySelector('.session-date');
    const startEl = card.querySelector('.session-start');
    const finishEl = card.querySelector('.session-finish');
    const locationEl = card.querySelector('.session-location');
    const reasonEl = card.querySelector('.session-reason');

    if (!dateEl.value) { localMsgs.push('Date required'); localCount++; if (!firstEl) firstEl = dateEl; }
    if (!startEl.value) { localMsgs.push('Start time required'); localCount++; if (!firstEl) firstEl = startEl; }
    if (!finishEl.value) { localMsgs.push('Finish time required'); localCount++; if (!firstEl) firstEl = finishEl; }

    // finish > start check (strict)
    if (startEl.value && finishEl.value) {
      const [sh, sm] = startEl.value.split(':').map(Number);
      const [fh, fm] = finishEl.value.split(':').map(Number);
      const smins = sh * 60 + (sm || 0);
      const fmins = fh * 60 + (fm || 0);
      if (!(fmins > smins)) { localMsgs.push('Finish must be after Start'); localCount++; if (!firstEl) firstEl = finishEl; }
    }

    if (!locationEl.value) { localMsgs.push('Location required'); localCount++; if (!firstEl) firstEl = locationEl; }
    if (!reasonEl.value) { localMsgs.push('Reason required'); localCount++; if (!firstEl) firstEl = reasonEl; }

    // Specimens: at least one and validate each
    const specimenRows = Array.from(card.querySelectorAll('.specimens-body tr'));
    if (specimenRows.length === 0) {
      localMsgs.push('At least one specimen required');
      localCount++;
      if (!firstEl) firstEl = card.querySelector('.add-specimen');
    } else {
      specimenRows.forEach((r, rIdx) => {
        const specEl = r.querySelector('.specimen-number');
        const urgEl = r.querySelector('.specimen-urgency');
        const tissueEl = r.querySelector('.specimen-tissue');
        const ptsEl = r.querySelector('.specimen-points');

        if (!specEl.value || String(specEl.value).trim() === '') {
          localMsgs.push(`Specimen ${rIdx + 1}: number required`); localCount++; if (!firstEl) firstEl = specEl;
        }
        if (!urgEl.value || !['Urgent','Routine'].includes(urgEl.value)) {
          localMsgs.push(`Specimen ${rIdx + 1}: urgency required`); localCount++; if (!firstEl) firstEl = urgEl;
        }
        if (!tissueEl.value) {
          localMsgs.push(`Specimen ${rIdx + 1}: tissue type required`); localCount++; if (!firstEl) firstEl = tissueEl;
        }
        if (ptsEl.value === '' || ptsEl.value === null) {
          localMsgs.push(`Specimen ${rIdx + 1}: points required`); localCount++; if (!firstEl) firstEl = ptsEl;
        } else {
          const p = Number(ptsEl.value);
          if (!Number.isInteger(p) || p < 0) {
            localMsgs.push(`Specimen ${rIdx + 1}: points must be integer ≥ 0`); localCount++; if (!firstEl) firstEl = ptsEl;
          }
        }
      });
    }

    // If this session has local issues, add to sessionSummaries and push first issue(s) to global errors (for focusing)
    if (localCount > 0) {
      sessionSummaries.push({ card, count: localCount, messages: localMsgs.slice(0,3), firstEl });
      // Add only the first issue element for global focus convenience
      if (firstEl) errors.push({ el: firstEl, message: `${prefix}: ${localMsgs[0]}` });
    }
  });

  return { errors, sessionSummaries };
}

/* Render compact error banner and per-session inline messages */
function renderErrorBanner() {
  const { errors, sessionSummaries } = collectErrors();
  const totalIssues = errors.length;

  // Clear previous inline errors (session cards)
  Array.from(sessionsList.querySelectorAll('.session-card')).forEach(card => {
    card.querySelector('.session-inline-errors').textContent = '';
    // clear per-input aria-invalid and error hints
    card.querySelectorAll('input, select').forEach(inp => {
      inp.removeAttribute('aria-invalid');
      const nextError = inp.parentElement.querySelector('.input-error');
      if (nextError) nextError.textContent = '';
    });
  });

  // Also clear top-level clinician field errors
  ['clinicianName','grade','esr','directorate','clinConfirmed','clinInitials','clinDate','budgetName','budgetInitials','budgetDate','reportingMonth'].forEach(id => {
    const el = $(`#${id}`);
    if (el) {
      const errEl = el.parentElement.querySelector('.input-error') || $(`#err-${id}`);
      if (errEl) errEl.textContent = '';
      el.removeAttribute('aria-invalid');
    }
  });

  if (totalIssues === 0) {
    errorBanner.hidden = true;
    sessionChips.innerHTML = '';
    // Clear any top-level error notes we may have shown previously
    return;
  }

  // Show banner
  errorBanner.hidden = false;

  // Build session chips
  sessionChips.innerHTML = '';
  sessionSummaries.forEach((s, i) => {
    const index = Array.from(sessionsList.querySelectorAll('.session-card')).indexOf(s.card) + 1;
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'chip';
    chip.textContent = `Session ${index} (${s.count} issue${s.count > 1 ? 's' : ''})`;
    chip.addEventListener('click', () => {
      s.card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      if (s.firstEl && typeof s.firstEl.focus === 'function') s.firstEl.focus();
    });
    sessionChips.appendChild(chip);

    // Also render small inline list inside the session card
    const inline = s.card.querySelector('.session-inline-errors');
    inline.textContent = 'Please correct: ' + s.messages.join('; ');
  });

  // Mark specific inputs as aria-invalid and render short messages near them (helpful for keyboard/screen reader)
  // We'll use collectErrors again to mark fields. We intentionally keep messages short to avoid walls of text.
  // For top-level errors, mark inputs
  const { errors: flatErrors } = collectErrors();
  flatErrors.slice(0, 50).forEach(fe => {
    try {
      const el = fe.el;
      if (!el) return;
      // set aria-invalid
      el.setAttribute('aria-invalid', 'true');
      // show short message near input if available
      const errHolder = (el.parentElement && el.parentElement.querySelector('.input-error')) || (el.id ? $(`#err-${el.id}`) : null);
      if (errHolder) errHolder.textContent = fe.message;
    } catch (e) {
      // ignore
    }
  });

  // Enable "Go to first error" to focus the first problematic element
  goToFirstErrorBtn.disabled = false;
}

/* Focus the first error element (used by the banner button) */
function focusFirstError() {
  const { errors } = collectErrors();
  if (errors.length === 0) return;
  const first = errors[0].el;
  if (first && typeof first.focus === 'function') {
    first.focus();
  } else {
    // fallback: focus banner
    errorBanner.focus();
  }
}

/* Validate form and update UI / banner */
function validateForm() {
  const { errors } = collectErrors();
  const isValid = errors.length === 0;
  submitBtn.disabled = !isValid;

  // Render banner (and inline session summaries)
  renderErrorBanner();

  return isValid;
}

/* ---------- Save / Load draft ---------- */

function buildPayload() {
  const meta = {
    generatedAt: new Date().toISOString(),
    kpiTarget: KPI_TARGET,
    reportingMonth: $('#reportingMonth').value || ''
  };

  const clinician = {
    name: $('#clinicianName').value,
    grade: $('#grade').value,
    esr: $('#esr').value,
    directorate: $('#directorate').value
  };

  const sessions = Array.from(sessionsList.querySelectorAll('.session-card')).map(card => {
    const sessionId = card.dataset.sessionId;
    const date = card.querySelector('.session-date').value;
    const startTime = card.querySelector('.session-start').value;
    const finishTime = card.querySelector('.session-finish').value;
    const location = card.querySelector('.session-location').value;
    const reason = card.querySelector('.session-reason').value;

    const specimens = Array.from(card.querySelectorAll('.specimens-body tr')).map(r => ({
      specimenNumber: r.querySelector('.specimen-number').value,
      urgency: r.querySelector('.specimen-urgency').value,
      tissueType: r.querySelector('.specimen-tissue').value,
      points: Number(r.querySelector('.specimen-points').value)
    }));

    const totalPoints = specimens.reduce((s, it) => s + (Number.isFinite(it.points) ? it.points : 0), 0);
    const casesReported = specimens.filter(s => s.specimenNumber && String(s.specimenNumber).trim() !== '').length;
    let kpiStatus = 'Below target';
    if (totalPoints === KPI_TARGET) kpiStatus = 'On target';
    else if (totalPoints > KPI_TARGET) kpiStatus = 'Over target';

    return {
      sessionId,
      date, startTime, finishTime, location, reason,
      metrics: {
        casesReported,
        totalPoints,
        kpiStatus,
        specimens
      }
    };
  });

  const declarations = {
    clinician: {
      confirmed: !!$('#clinConfirmed').checked,
      initials: $('#clinInitials').value,
      date: $('#clinDate').value
    },
    budgetHolder: {
      name: $('#budgetName').value,
      initials: $('#budgetInitials').value,
      date: $('#budgetDate').value,
      email: $('#budgetEmail').value || ''
    }
  };

  // Compute monthly total (optional in JSON but useful)
  const monthlyTotalPoints = sessions.reduce((s, ss) => s + (ss.metrics && ss.metrics.totalPoints ? ss.metrics.totalPoints : 0), 0);

  return { meta: { ...meta, monthlyTotalPoints }, clinician, sessions, declarations };
}

function saveDraft() {
  try {
    const payload = buildPayload();
    localStorage.setItem(DRAFT_KEY, JSON.stringify(payload));
    alert('Draft saved locally in your browser.');
  } catch (err) {
    alert('Unable to save draft: ' + err.message);
  }
}

function loadDraft() {
  const raw = localStorage.getItem(DRAFT_KEY);
  if (!raw) {
    alert('No draft found.');
    return;
  }
  try {
    const payload = JSON.parse(raw);
    populateFromPayload(payload);
    alert('Draft loaded.');
  } catch (err) {
    alert('Unable to load draft: ' + err.message);
  }
}

function populateFromPayload(payload) {
  if (!payload) return;
  $('#reportingMonth').value = payload.meta && payload.meta.reportingMonth ? payload.meta.reportingMonth : '';

  const c = payload.clinician || {};
  $('#clinicianName').value = c.name || '';
  $('#grade').value = c.grade || '';
  $('#esr').value = c.esr || '';
  $('#directorate').value = c.directorate || '';

  // Clear existing sessions
  sessionsList.innerHTML = '';
  sessionCounter = 0;

  const sessions = payload.sessions || [];
  if (sessions.length === 0) {
    addSession();
  } else {
    sessions.forEach(s => addSession(s));
  }

  const d = payload.declarations || {};
  const clin = d.clinician || {};
  $('#clinConfirmed').checked = !!clin.confirmed;
  $('#clinInitials').value = clin.initials || '';
  $('#clinDate').value = clin.date || '';

  const bud = d.budgetHolder || {};
  $('#budgetName').value = bud.name || '';
  $('#budgetInitials').value = bud.initials || '';
  $('#budgetDate').value = bud.date || '';
  $('#budgetEmail').value = bud.email || '';

  // Update displays & validation
  Array.from(sessionsList.querySelectorAll('.session-card')).forEach(card => refreshSession(card));
  validateForm();
}

/* Helper to populate a session card from session object */
function populateSessionFromObject(card, sessionObj) {
  if (!sessionObj) return;
  // Use provided sessionId but ensure it's marked used to avoid reuse
  const sid = sessionObj.sessionId || generateUUID();
  card.dataset.sessionId = sid;
  card.querySelector('.session-id').value = sid;
  markSessionIdUsed(sid);

  card.querySelector('.session-date').value = sessionObj.date || '';
  card.querySelector('.session-start').value = sessionObj.startTime || '';
  card.querySelector('.session-finish').value = sessionObj.finishTime || '';
  card.querySelector('.session-location').value = sessionObj.location || '';
  card.querySelector('.session-reason').value = sessionObj.reason || '';

  // Specimens: clear then add
  const tbody = card.querySelector('.specimens-body');
  tbody.innerHTML = '';
  const specimens = (sessionObj.metrics && sessionObj.metrics.specimens) || [];
  if (specimens.length === 0) addSpecimenRow(card);
  else specimens.forEach(sp => addSpecimenRow(card, {
    specimenNumber: sp.specimenNumber,
    urgency: sp.urgency,
    tissueType: sp.tissueType,
    points: sp.points
  }));

  refreshSession(card);
}

/* ---------- Submit & exports ---------- */

function handleSubmit(ev) {
  ev.preventDefault();
  if (!validateForm()) return;

  const payload = buildPayload();

  const esr = (payload.clinician && payload.clinician.esr) ? payload.clinician.esr.replace(/\s+/g, '_') : 'noESR';
  const reportingMonth = payload.meta.reportingMonth || `${(new Date()).getFullYear()}-01`;
  const base = `claim_${esr}_${reportingMonth}`;

  // JSON
  const jsonStr = JSON.stringify(payload, null, 2);
  downloadFile(`${base}.json`, jsonStr, 'application/json');

  // CSV: one row per specimen
  const headers = [
    'reportingMonth','clinicianName','grade','esr','directorate',
    'sessionId','sessionDate','startTime','finishTime','location','reason',
    'specimenNumber','urgency','tissueType','points',
    'sessionTotalPoints','sessionKpiStatus'
  ];
  const rows = [];
  payload.sessions.forEach(s => {
    const sessionTotal = s.metrics.totalPoints;
    const sessionKpi = s.metrics.kpiStatus;
    s.metrics.specimens.forEach(sp => {
      rows.push({
        reportingMonth: payload.meta.reportingMonth,
        clinicianName: payload.clinician.name,
        grade: payload.clinician.grade,
        esr: payload.clinician.esr,
        directorate: payload.clinician.directorate,
        sessionId: s.sessionId,
        sessionDate: s.date,
        startTime: s.startTime,
        finishTime: s.finishTime,
        location: s.location,
        reason: s.reason,
        specimenNumber: sp.specimenNumber,
        urgency: sp.urgency,
        tissueType: sp.tissueType,
        points: sp.points,
        sessionTotalPoints: sessionTotal,
        sessionKpiStatus: sessionKpi
      });
    });
  });

  const csv = buildCSV(headers, rows);
  downloadFile(`${base}.csv`, csv, 'text/csv;charset=utf-8;');

  localStorage.removeItem(DRAFT_KEY);
  alert('Claim exported (JSON & CSV). Files downloaded to your device.');
  validateForm();
}

/* ---------- Mailto helper ---------- */

function handleBudgetEmailChange() {
  const email = $('#budgetEmail').value.trim();
  prepareEmailBtn.hidden = !email;
}

function prepareBudgetEmail() {
  const email = $('#budgetEmail').value.trim();
  if (!email) { alert('Please enter a budget holder email first.'); return; }
  const clinicianName = $('#clinicianName').value || '';
  const reportingMonth = $('#reportingMonth').value || '';
  const subj = `Claim submission for ${clinicianName} — ${reportingMonth}`;
  const bodyLines = [
    `Dear ${$('#budgetName').value || 'Budget holder'},`,
    '',
    `Please find the monthly claim for ${clinicianName} for ${reportingMonth}.`,
    'I will attach the exported files (JSON & CSV) from the prototype to this email.',
    '',
    'Kind regards,',
    clinicianName
  ];
  const body = encodeURIComponent(bodyLines.join('\n'));
  const mailto = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subj)}&body=${body}`;
  window.location.href = mailto;
}

/* ---------- Reset ---------- */

function handleReset() {
  if (!confirm('Reset the entire form? This will clear fields and sessions.')) return;
  form.reset();
  sessionsList.innerHTML = '';
  sessionCounter = 0;
  addSession();
  validateForm();
}